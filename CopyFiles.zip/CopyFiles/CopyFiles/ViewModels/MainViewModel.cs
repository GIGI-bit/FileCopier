﻿using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace CopyFiles.ViewModels;

public class MainViewModel : INotifyPropertyChanged
{
    private string _fromAddress;
    private string _toAddress;
    private int _progress;
    public int ProgressBar { get { return _progress; } set {  _progress = value; OnPropertyChenged(); } }
    public string FromAddress { get { return _fromAddress; } set {  _fromAddress = value; OnPropertyChenged(); } }
    public string ToAddress { get { return _toAddress; } set { _toAddress = value;  OnPropertyChenged(); } }
    private Thread thread;
    public ICommand Suspend {  get; set; }
    public ICommand Resume { get; set; }
    public ICommand Abort { get; set; }
    public ICommand Copy { get; set; }

    public MainViewModel()
    {
        thread = new Thread(() => {
            try
            {
                using (FileStream source = File.OpenRead(FromAddress)) 
                using (FileStream des = File.Create(ToAddress))
                {
                    var buffer = new byte[1024];
                    int bytesRead;
                    long totalBytesRead = 0;
                    long fileSize = source.Length;

                    while ((bytesRead = source.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        des.Write(buffer, 0, bytesRead);
                        totalBytesRead += bytesRead;
                        Thread.Sleep(2000);
                        ProgressBar = (int)((totalBytesRead * 100) / fileSize);

                        
                        
                    }


                }

            }
            catch(Exception ex) { MessageBox.Show(ex.Message); }
        
        });
        Suspend = new RelayCommand(execSus);
        Resume = new RelayCommand(execRes);
        Abort = new RelayCommand(execAb);
        Copy = new RelayCommand(execCopy);
    }

    private void execCopy()
    {
        thread.Start();
    }

    private void execAb()
    {
        thread.Abort();
    }

    private void execRes()
    {
        thread.Resume();
    }

    private void execSus()
    {
        thread.Suspend();
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChenged([CallerMemberName] string propertName = null)
    {
        if (PropertyChanged != null)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertName));
        }
    }
}
